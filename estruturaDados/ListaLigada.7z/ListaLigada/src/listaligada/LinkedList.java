package listaligada;

public class LinkedList {

    private Node header;
    private Node trailer;
    private int size;

    public LinkedList() {
        trailer = null;
        header = null;
        size = 0;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        if (size == 0) {
            return true;
        } else {
            return false;
        }
    }

    public Node first() {
        return header;
    }

    public Node last() {
        return trailer;
    }

    public void addFirst(String nomeAnimal) {
        Node novo = new Node(nomeAnimal);

        if (isEmpty()) {
            header = novo;
            trailer = novo;
        } else {
            novo.setNext(header);
            header = novo;
        }
        size++;
    }

    public void addLast(String nomeAnimal) {
        Node novo = new Node(nomeAnimal);

        if (size == 0) {
            header = novo;
            trailer = novo;
        } else {
            trailer.setNext(novo);
            trailer = novo;
        }
        size++;
    }

    public void addAfter(String novo, String no) throws Exception {

        if (isEmpty()) {
            throw new Exception("Lista vazia!");
        } else if (no.equals(trailer.getNomeAnimal())) {
            addLast(novo);
        } else {
            Node novoNo = new Node(novo);
            Node aux = header;
            while (aux.getNext() != null) {
                if (aux.getNomeAnimal().equals(no)) {
                    novoNo.setNext(aux.getNext());
                    aux.setNext(novoNo);
                }
            }
        }

        size++;
    }

    public void addBefore(String novo, Node no) throws Exception {
        if (isEmpty()) {
            throw new Exception("Lista vazia!");
        } else if(no.equals(header.getNomeAnimal())){
            addFirst(novo);
        } else{
            Node novoNo = new Node(novo);  
            Node aux = header; 
            while (aux.getNext() != null) {
                 if (aux.getNext()==no) {
                     novoNo.setNext(no);
                     aux.setNext(novoNo);                     
                 }
            }            
            /*
            Node novoNo = new Node(novo);
            Node aux, ant = null;
            for(aux = header; !(aux.getNomeAnimal().equals(no)); aux = aux.getNext()){
                ant = aux;
            }
            ant.setNext(novoNo);
            novoNo.setNext(aux);
            */
        }        
        size++;
    }
    
    public void remove(Node no) throws Exception{
        if(isEmpty()){
            throw new Exception("Lista vazia!");
        } else if(no.getNomeAnimal().equals(trailer.getNomeAnimal())) {
            
        } 
        
    }
    
}
