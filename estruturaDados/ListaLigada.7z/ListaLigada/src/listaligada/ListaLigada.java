
package listaligada;


public class ListaLigada {


    public static void main(String[] args) {
        
        
        
    }
    
}
