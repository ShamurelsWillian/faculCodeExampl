package listaligada;

public class Node {

    private String nomeAnimal;
    private Node next;

    public Node(String nomeAnimal) {
        this.nomeAnimal = nomeAnimal;
        next = null;
    }

    public String getNomeAnimal() {
        return nomeAnimal;
    }

    public void setnomeAnimal(String nomeAnimal) {
        this.nomeAnimal = nomeAnimal;
    }

    public Node getNext() {
        return next;
    }

    public void setNext(Node no) {
        this.next = no;
    }

}
