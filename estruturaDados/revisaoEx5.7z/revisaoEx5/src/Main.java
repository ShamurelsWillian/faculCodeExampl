public class Main {
    public static void main(String[] args) {
        int[][] M;
        int vazio = 0;
        
        M = new int[][]{{1,4,2,3,5,0,6,2},
            {1,4,2,3,4,1,0,5},
            {6,3,5,4,1,2,1,1},
            {5,0,3,4,0,3,2,1},
            {5,1,2,5,3,0,0,5},
            {6,0,3,4,1,2,0,0},
            {1,2,4,3,5,6,2,3},
            {1,4,2,3,1,1,6,5},
            {1,3,2,4,3,5,4,6},
            {5,2,3,4,1,0,3,3}};
        System.out.println("Apartamentos: ");

        for(int i=0; i<10; i++){ //for para rodar matriz M
            for(int j=0; j<8; j++){
                System.out.print(M[i][j] + " "); //printa o número de moradores de cada apartamento
                if(M[i][j]==0) vazio += 1; //somar a quantidade de apartamentos vazios
            }            
            System.out.println("");
        }     
                
        System.out.println("Número de apartamentos vazios: " + vazio);
        
        int somaAndar = 0;
        int somaPredio = 0;
        int maiorAndar = 0;
        int contadorAndar = 0;
        for(int i=0; i<10; i++){ //for para verificar apartamento com maior número de moradores
            somaAndar = 0; //reseta o contador do andar
            for(int j=0; j<8; j++){
                somaAndar += M[i][j]; //soma os moradores do andar 
                somaPredio += M[i][j];
            }
            if(somaAndar>contadorAndar){ //verifica se o andar atual tem mais moradores que o anterior
                contadorAndar = somaAndar;
                maiorAndar = i+1;
            }
        } 
        
        System.out.println("Andar com maior número de moradowres: " + maiorAndar);
        System.out.println("Total de moradores no prédio: " + somaPredio);
        
        
        
        
    }   
}

